public class TestAll {
    public static void main(String[] args) {

        MyLinkedList<Integer> list = new MyLinkedList<>();

        System.out.println("EMPTY LIST");
        System.out.println(list.makePalindrome());

        System.out.println("\nONE ELEMENT");
        list.append(new Integer(1));
        System.out.println(list.makePalindrome());
        list.clear();

        System.out.println("\nTHREE ELEMENTS");
        list.append(new Integer(1));
        list.append(new Integer(2));
        list.append(new Integer(3));
        System.out.println(list.makePalindrome());
        list.clear();

        System.out.println("\nFOUR ELEMENTS");
        list.append(new Integer(8));
        list.append(new Integer(9));
        list.append(new Integer(1));
        list.append(new Integer(4));
        System.out.println(list.makePalindrome());
    }
}
